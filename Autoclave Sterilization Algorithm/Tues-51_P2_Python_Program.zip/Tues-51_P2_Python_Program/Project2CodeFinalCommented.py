ip_address = 'localhost' # Enter your IP Address here
project_identifier = 'P2B' # Enter the project identifier i.e. P2A or P2B
#--------------------------------------------------------------------------------
import sys
sys.path.append('../')
from Common.simulation_project_library import *

hardware = False
QLabs = configure_environment(project_identifier, ip_address, hardware).QLabs
arm = qarm(project_identifier,ip_address,QLabs,hardware)
potentiometer = potentiometer_interface()
#--------------------------------------------------------------------------------
# STUDENT CODE BEGINS
#---------------------------------------------------------------------------------

import random

# Define our pick up location in a list with xyz coordinates

pickUpLocation = [0.51, 0.036, -0.047]

# Define our origin location in a list with xyz coordinates

origin = [0.406, 0.0, 0.483]

# This function returns the colour of the container, by matching to its ID

# AFRAZ

def colour(a): # a is a dummy variable
    if a == 1 or a == 4: # for large and small red containers
        return 'red' # '' '' 
    elif a == 2 or a == 5: # '' ''
        return 'green'
    else: # '' ''
        return 'blue'

# This function picks up the container at the pick up location, and then returns home

# AFRAZ

def pickUp():
    time.sleep(1)
    arm.move_arm(pickUpLocation[0], pickUpLocation[1], pickUpLocation[2]) # Move arm to our pick up location using list indexing
    time.sleep(1)
    arm.control_gripper(40) # Close the gripper to hold on container
    time.sleep(1)
    arm.move_arm(origin[0], origin[1], origin[2]) # Move arm to the origin using list indexing

# This function, matches the position of the arm with respect to the autoclaves colour.
# It returns the location of the autoclave when it is rotationally aligned, by taking in the ID

# AFRAZ

def posColour(code):
    if code == 1 or code == 4:
        loc = [-0.003, -0.406, 0.483]
    elif code == 2 or code == 5:
        loc = [-0.373, 0.161, 0.483]
    else:
        loc = [0.021, 0.405, 0.483]
    return loc

# This function returns the position of each unique container, when it is in the position prior to be dropped

# FATIMA

def posUnique(code):
    if code == 1:
        loc = [-0.004,  -0.597, 0.228]
    elif code == 2:
        loc = [-0.604, 0.224, 0.274]
    elif code == 3:
        loc = [0.0, 0.6, 0.235]
    elif code == 4:
        loc = [0.0, -0.335, 0.164]
    elif code == 5:
        loc = [-0.396, 0.147, 0.148]
    else:
        loc = [-0.0, 0.371, 0.154]
    return loc

# This function rotates the base of the Q arm based on the input of right poteniometer, and terminates once it aligns to the respective autoclave, matching the input ID

# FATIMA

def rotate(x):
    old_reading = potentiometer.right() # Take the first reading of the right potentiometer
    arm.rotate_base(3.48)
    while True:
        new_reading = potentiometer.right() # Take another reading
        delta = new_reading - old_reading # Calculate the change in the potentiometer value
        increment = 348*delta # Multiply by 348 in order to get it in terms of degrees
        i = 0
        if posColour(x) == list(arm.effector_position()): # We terminate this function one we match with the autoclave
            break
        if delta < 0: # In the case that our rotation is in the negative direction
            while i < abs(increment):
                if posColour(x) == list(arm.effector_position()): # We terminate this function if we match with the autoclave
                    break
                arm.rotate_base(-3.48) # We rotate the base in small increments until either there is a match with the autoclave, or the desired rotation by the input is fulfilled
                i = i + 3.48
        elif delta > 0:
            while i < abs(increment):
                if posColour(x) == list(arm.effector_position()): # We terminate this function if we match with the autoclave
                    break
                arm.rotate_base(3.48) # We rotate the base in small increments until either there is a match with the autoclave, or the desired rotation by the input is fulfilled
                i = i + 3.48
        old_reading = new_reading # Update the first reading

# This function will drop the container in the respective bin based on left potentiometer input

# AFRAZ

def drop(z):
    while True:
        if potentiometer.left() > 0.5 and potentiometer.left() < 1.0: # When dropping small containers, the threshold is between 0.5 and 1.0
            if z == 1 or z == 2 or z == 3: # IDs of small containers
                arm.activate_autoclaves() 
                time.sleep(0.2)
                arm.move_arm(posUnique(z)[0], posUnique(z)[1], posUnique(z)[2]) # Move arm to its unique position
                time.sleep(0.2)
                arm.control_gripper(-40) # Release container
                time.sleep(0.2)
                arm.deactivate_autoclaves()
                time.sleep(0.2)
                print("Placed container in autoclave bin!")
                break
            else:
                print("Does not match: Small containers require left potentiometer to be between 0.5 and 1.0.") # When input is incorrect
                continue
        elif potentiometer.left() == 1.0: # When dropping large containers, the threshold is right at 1.0
            if z == 4 or z == 5 or z == 6: # IDs of large containers
                arm.activate_autoclaves()
                time.sleep(0.2)
                arm.move_arm(posUnique(z)[0], posUnique(z)[1], posUnique(z)[2]) # Move arm to its unique position
                arm.open_autoclave(colour(z)) # Open drawer
                time.sleep(0.2)
                arm.control_gripper(-40) # Release container
                time.sleep(1)
                arm.open_autoclave(colour(z), False) # Close drawer
                time.sleep(0.2)
                arm.deactivate_autoclaves()
                time.sleep(0.2)
                print("Placed container in autoclave bin!")
                break
            else:
                print("Does not match: Large containers require left potentiometer to be between at 1.0.") # When input is incorrect
                continue
    while True: # This ensures that the user sets both potentiometers to 50% before repeating the cycle.
        if potentiometer.left() != 0.5:
            if potentiometer.right() != 0.5:
                print("Please set both potentiometers to 50%.") # Initialize back to 0.5 for right potentiometer
                continue
            else:
                pass
        elif potentiometer.left() == 0.5:
            if potentiometer.right() != 0.5:
                print("Please set both potentiometers to 50%.") # Initialize back to 0.5 for right potentiometer
                continue
            elif potentiometer.right() == 0.5:
                break
            

            
    arm.home() # Return home

# AFRAZ AND FATIMA

def main():
    inv = [1, 2, 3, 4, 5, 6] # Inventory of 6 containers
    while True:
        if len(inv) == 0: # Terminate the main program if all 6 containers are placed
            break
        item = random.choice(inv) # Randomly choose a container
        arm.spawn_cage(item)
        pickUp()
        rotate(item)
        drop(item)           
        inv.remove(item) # Remove the container from inventory since its placed
    print("All done, thank you!")

main()

#---------------------------------------------------------------------------------
# STUDENT CODE ENDS
#---------------------------------------------------------------------------------
    

    

